# 📊 Portfolio Dashboard

Web app in Python/Streamlit per la gestione, l'analisi e il ribilanciamento
di portafogli finanziari multi-categoria, con dati in tempo reale da Yahoo Finance.

## Struttura del progetto

```
portfolio_dashboard/
├── app.py                     # Entry point Streamlit (UI, tab, sidebar)
├── requirements.txt           # Dipendenze Python
├── .streamlit/
│   └── config.toml            # Tema grafico dell'app
├── data/
│   └── portfolios.json        # Persistenza dati (creato automaticamente al primo avvio)
└── src/
    ├── data_fetcher.py        # Recupero prezzi/FX da Yahoo Finance (yfinance) + caching
    ├── portfolio_manager.py   # Modello dati, persistenza JSON, CRUD portafogli/posizioni
    ├── calculations.py        # Calcolo valori di mercato, P&L, allocazioni, rebalancing
    └── charts.py               # Grafici Plotly (donut, barre target vs effettivo, gauge)
```

## Architettura

- **Persistenza**: i dati (sub-portafogli e posizioni) sono salvati in `data/portfolios.json`.
  Al primo avvio viene creato un dataset di esempio (Apple, Nvidia, un ETF MSCI World,
  Bitcoin e liquidità) che puoi modificare o cancellare liberamente.
- **Dati di mercato**: `yfinance` recupera prezzo corrente, valuta nativa e cambio giornaliero
  per ogni ticker; i risultati sono in cache 5 minuti (`st.cache_data`) per non sovraccaricare
  Yahoo Finance e rendere l'app reattiva.
- **Valuta base**: tutti i valori vengono convertiti in **EUR** usando i tassi di cambio
  Yahoo Finance (es. `USDEUR=X`), così puoi mixare titoli USD, EUR, ecc. nello stesso portafoglio.
- **Rebalancing**: per ogni posizione l'app calcola `% Effettiva`, la confronta con la
  `% Target` che imposti tu, e determina l'importo (in EUR e in valuta nativa) e il numero
  approssimativo di unità/azioni da comprare (+) o vendere (−) per riallineare il portafoglio.

## Requisiti

- Python 3.10 o superiore
- Connessione internet (per il recupero dei dati da Yahoo Finance)

## Installazione

1. **Estrai il progetto** in una cartella a tua scelta ed entra nella directory:

   ```bash
   cd portfolio_dashboard
   ```

2. **Crea un ambiente virtuale** (fortemente consigliato):

   ```bash
   python3 -m venv venv
   source venv/bin/activate        # su Windows: venv\Scripts\activate
   ```

3. **Installa le dipendenze**:

   ```bash
   pip install -r requirements.txt
   ```

## Esecuzione

```bash
streamlit run app.py
```

L'app si aprirà automaticamente nel browser all'indirizzo `http://localhost:8501`.

## Guida rapida all'uso

1. **Sidebar** → *Nuovo sub-portafoglio*: crea le tue categorie (es. "Azioni Singole", "ETF",
   "Crypto", "Cash", oppure quelle che preferisci — non sono vincolate).
2. **Sidebar** → *Nuova posizione*: aggiungi un titolo specificando ticker Yahoo Finance
   (es. `AAPL`, `SWDA.MI`, `BTC-EUR`), categoria, settore, quantità, prezzo medio di carico,
   valuta e **Target %** (il peso che vuoi che quel titolo abbia sul totale del portafoglio).
   - Per la liquidità usa ticker `CASH`: il "prezzo" coincide con l'importo stesso.
3. **Tab Dashboard**: grafici a ciambella per allocazione per Categoria, Settore, Titolo
   e (in vista consolidata) per Sub-Portafoglio.
4. **Tab Rebalancing**: confronto Target % vs Effettiva %, con tabella degli importi
   esatti da comprare/vendere per riallineare il portafoglio. Verde = da comprare,
   rosso = da vendere.
5. **Tab Posizioni**: tabella dettagliata con Profitto/Perdita colorato (verde/rosso)
   e variazione giornaliera.
6. **Tab Gestione**: tabella editabile (aggiungi, modifica o elimina righe direttamente),
   con pulsante **Salva modifiche** per persistere su disco.
7. **Filtro Vista** (sidebar, in alto): passa dalla vista consolidata (tutti i portafogli)
   alla vista di un singolo sub-portafoglio.

## Note su ticker Yahoo Finance

- Azioni USA: simbolo semplice, es. `AAPL`, `NVDA`, `MSFT`
- Azioni/ETF quotati a Milano: suffisso `.MI`, es. `SWDA.MI`, `ENEL.MI`
- Crypto: formato `SIMBOLO-VALUTA`, es. `BTC-EUR`, `ETH-USD`
- Se un ticker non viene trovato, l'app userà il prezzo medio di carico come fallback
  e lo segnalerà nell'espansore "Ticker con errori" nel tab Posizioni.

## Possibili estensioni future

- Autenticazione multi-utente e database (SQLite/PostgreSQL) al posto del JSON locale
- Storico valore del portafoglio nel tempo (grafico a linee) salvando uno snapshot giornaliero
- Export report PDF/Excel del rebalancing
- Notifiche quando uno scostamento dal target supera una soglia impostabile
- Architettura disaccoppiata React + FastAPI per un'esperienza ancora più reattiva

## Disclaimer

Applicazione per uso personale. I dati Yahoo Finance possono essere ritardati di
15-20 minuti e non costituiscono consulenza finanziaria.
